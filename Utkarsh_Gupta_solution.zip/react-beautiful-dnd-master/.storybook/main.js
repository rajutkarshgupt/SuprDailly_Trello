module.exports = {
  addons: ['storybook-addon-performance/register','@storybook/addon-storysource'],
};
