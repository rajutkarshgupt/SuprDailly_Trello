// @flow

export const grid: number = 8;
export const borderRadius: number = 2;
