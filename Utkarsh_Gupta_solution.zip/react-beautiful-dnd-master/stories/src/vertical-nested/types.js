// @flow

export type NestedQuoteList = {|
  id: string,
  title: string,
  children: Array<any>,
|};
