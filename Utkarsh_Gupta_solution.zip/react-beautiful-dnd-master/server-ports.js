// @flow
const ports = {
  storybook: 9002,
  cspServer: 9003,
};

module.exports = ports;
