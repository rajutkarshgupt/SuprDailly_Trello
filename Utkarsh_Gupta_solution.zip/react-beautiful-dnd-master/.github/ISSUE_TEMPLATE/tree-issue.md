---
name: 🌲@atlaskit/tree
about: Bugs and feature requests for @atlaskit/tree
labels: 'wontfix ☠️'
---

Please head to the [`@atlaskit/tree` issue tracker](https://ecosystem.atlassian.net/servicedesk/customer/portal/24/create/236).

We do not track `@atlaskit/tree` issues in the `react-beautiful-dnd` project
